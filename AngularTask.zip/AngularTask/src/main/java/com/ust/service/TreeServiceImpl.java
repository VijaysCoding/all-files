package com.ust.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ust.model.Tree;
import com.ust.repository.TreeRepository;

@Service
public class TreeServiceImpl implements TreeService {
	
	@Autowired
	private TreeRepository repo;
	
	@Override
	public List<Tree> getAllCustomer() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	@Override
	public Tree CreateCustomer(Tree tree) {
		// TODO Auto-generated method stub
		return repo.save(tree);
	}
	@Override
	public void DeleteCustomer(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}
}
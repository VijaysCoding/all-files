package com.ust.service;
import java.util.List;

import com.ust.model.Tree;

public interface TreeService {
	
	public List<Tree> getAllCustomer();
	public Tree CreateCustomer(Tree tree);
	void DeleteCustomer(int id);
}
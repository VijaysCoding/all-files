package com.ust.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.model.Tree;
import com.ust.service.TreeService;

@RestController
@CrossOrigin
public class TreeController {
	
	@Autowired
	private TreeService services;
	
	@PostMapping("/create")
	public ResponseEntity<Tree> CreateCustomer(@RequestBody Tree  tree){
		Tree saved=services.CreateCustomer(tree);
		return new ResponseEntity<>(saved,HttpStatus.CREATED);
	}
	
	@GetMapping("/get")
	public ResponseEntity<List<Tree>> getAllCustomer(){
		List<Tree> getall=services.getAllCustomer();
		return new ResponseEntity<>(getall,HttpStatus.OK);
	}
	
	@DeleteMapping("/deletecustomer/{id}")
	public ResponseEntity<String> DeleteCustomer(@PathVariable("id") int id){
		services.DeleteCustomer(id);
		return ResponseEntity.ok("success");
	}
}
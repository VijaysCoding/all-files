export class Restaurant {
    name?:string;
    type?:string;
    price?:number;
    rating?:string;
    quantity?:string;
    children?:Restaurant[];
}

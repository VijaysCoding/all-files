import { FlatTreeControl } from '@angular/cdk/tree';
import { Component } from '@angular/core';
import { MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';
import { Restaurant } from 'src/app/model/restaurant.model';
import { RestaurantService } from 'src/app/services/restaurant.service';

interface RestaurantFlatNode{
  expandable:boolean;
  name:string;
  level:number;
}

const DATA:Restaurant[]=[];

@Component({
  selector: 'app-restaurant',
  templateUrl: './restaurant.component.html',
  styleUrls: ['./restaurant.component.scss']
})
export class RestaurantComponent {

  displayColumns :string[] =['name','type','price','rating','quantity','actions'];
  private transformer = (node:Restaurant, level: number)=> {
    return {
      expandable : !!node.children && node.children.length > 0,
      name:node.name,
      type:node.type,
      price:node.price,
      rating:node.rating,
      quantity:node.quantity,
      level:level
    };
  }
  treeControl = new FlatTreeControl<RestaurantFlatNode>(node => node.level, node => node.expandable);
  treeFlattener = new MatTreeFlattener(
    this.transformer, node => node.level,
    node => node.expandable, node => node.children);
   dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  constructor(private ser:RestaurantService) {
    this.dataSource.data = DATA;
    this.ser.getAllData().subscribe(DATA=>
      {
        this.dataSource.data = DATA;
        console.log(this.dataSource);
      })
   }
   hasChild =(_:number, node:RestaurantFlatNode)=> node.expandable;

}

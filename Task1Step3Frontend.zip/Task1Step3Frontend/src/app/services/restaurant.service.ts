import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Restaurant } from '../model/restaurant.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  URL='http://localhost:8090/rest/get';
  constructor(private http: HttpClient) { }

  getAllData():Observable<Restaurant[]>{
    return this.http.get<Restaurant[]>(this.URL);
  }
}

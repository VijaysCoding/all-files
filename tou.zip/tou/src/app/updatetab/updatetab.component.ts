import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Entry } from '../entry';
import { EntryService } from '../entry.service';

@Component({
  selector: 'app-updatetab',
  templateUrl: './updatetab.component.html',
  styleUrls: ['./updatetab.component.css']
})
export class UpdatetabComponent implements OnInit{

  @Input() dashaccount ;
  account:number;
  uEntry:Entry = new Entry();

  closeModal = true;

  constructor(private router:ActivatedRoute,private entryservice:EntryService,private rout:Router)
  {

  }
  ngOnInit(): void {
    this.getUserById(this.dashaccount);
    console.log(this.dashaccount);
  }
  closeModalEvent(){
    this.closeModal = false;
  }
  getUserById(selectedAccount: any)
  {
    // this.account = this.router.snapshot.params['account'];
    this.entryservice.getDataById(selectedAccount).subscribe({
      next: (data) =>
      {
        this.uEntry = data[0];
        this.uEntry.createdOn
        console.log(this.uEntry);
      },
      error: (e) =>{
        console.log(e);
      }
    });
  }

  // private getUser()
  // {
  //   this.account = this.router.snapshot.params['account'];
  //   this.entryservice.getDataById(this.account).subscribe({
  //     next:(data) =>
  //     {
  //       this.uEntry=data;
  //     },
  //     error: (e) =>
  //     {
  //       console.log(e);
  //     }
  //   });
  // }

  updateTab()
  {
    this.entryservice.updatetab(this.uEntry,this.dashaccount).subscribe({
      next:(data) =>{
        console.log(data);
        this.closeModal = false;
        
      },
      error: (e) =>
      {
        console.log(e);
      }
    });
  }

  onSubmit(){
    console.log(this.uEntry);
    this.updateTab();
    
  }
  
   
  
  

}

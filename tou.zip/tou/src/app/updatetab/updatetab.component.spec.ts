import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatetabComponent } from './updatetab.component';

describe('UpdatetabComponent', () => {
  let component: UpdatetabComponent;
  let fixture: ComponentFixture<UpdatetabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatetabComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdatetabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

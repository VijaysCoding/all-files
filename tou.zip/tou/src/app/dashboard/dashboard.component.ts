import { Component } from '@angular/core';
import {FlatTreeControl} from '@angular/cdk/tree';
import {MatTreeFlatDataSource, MatTreeFlattener} from '@angular/material/tree';


interface TabNode {
  name: string;
  account?: number;
  created_on?: string;
  created_by?: string;
  currency?:string;
  children?: TabNode[];
  check?:number;
}

const TREE_DATA: TabNode[] = [
  {
    name: 'Assets',

    children: [

      {

        name: 'External Accounting',

        children: [

          {check:1,name: 'Cash Reserve', account: 1010131,created_on:'30.08.2020',created_by:'Company A',currency:'CHF'},

          {check:1,name: 'Values Undergoing Collection', account: 1012131,created_on:'25.08.2020',created_by:'Company B',currency:'CHF'},

          {check:1,name: 'Bank Account Number', account: 1011000,created_on:'22.08.2020',created_by:'Company C',currency:'EUR'},

          {check:1,name: 'Bank Clearning Number', account: 1011100,created_on:'21.08.2020',created_by:'Company E',currency:'CHF'},

          {check:1,name: 'IFX Adjustment Account:FI-GL', account: 1011200,created_on:'12.08.2020',created_by:'Company F',currency:'EUR'},

        ]
      
      }, 
      {

        name: 'Cash and Cash Balance',

        children: [

          // {name: 'Pumpkins', account: 30},

          // {name: 'Carrots', account: 40},
          {check:1,name: 'Values Undergoing Collection', account: 20,created_on:'25.08.2020',created_by:'Company D',currency:'CHF'},

          {check:1,name: 'Bank Clearning Number', account: 20,created_on:'25.08.2020',created_by:'Company E',currency:'CHF'},

        ]

      },

    ]
  },
];

interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  account: number;
  created_on: string;
  created_by: string;
  currency:string;
  level: number;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  displayedColumns: string[] = ['check','name', 'account', 'created_on', 'created_by','currency'];
  
  
  private transformer = (node: TabNode, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      check:node.check,
      name: node.name,
      account: node.account,
      created_on:node.created_on,
      created_by:node.created_by,
      currency:node.currency,
      level: level,
    };
  }

  treeControl = new FlatTreeControl<ExampleFlatNode>(
      node => node.level, node => node.expandable);

  treeFlattener = new MatTreeFlattener(
      this.transformer, node => node.level, 
      node => node.expandable, node => node.children);

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  selection: any;

  constructor() {
    this.dataSource.data = TREE_DATA;
  }

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

}

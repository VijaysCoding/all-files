import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Tree } from './tree';

@Injectable({
  providedIn: 'root'
})
export class TreeService {

  constructor(private http:HttpClient) { }

  getTree():Observable<Tree[]>{
    return this.http.get<Tree[]>(`http://localhost:8080/api/v1/get`);
  }
}

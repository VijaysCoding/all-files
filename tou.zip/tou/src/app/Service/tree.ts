export interface Tree {
    
	description:string;
    uId : number;
    cgpa: string;
    jYear: number;
    pYear: number;
    childTree:Tree[];
}
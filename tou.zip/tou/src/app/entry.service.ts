import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Entry } from './entry';

@Injectable({
  providedIn: 'root'
})
export class EntryService {

  constructor(private _http:HttpClient) { }

  createtab(entry: Entry):Observable<any>
  {
    return this._http.post<any>(`http://localhost:8090/api/v1/create`,entry);
  }
  deletetab(account:number):Observable<object>
  {
    return this._http.delete(`http://localhost:8090/api/v1/deletetab/${account}`);
  }
  updatetab(entry: Entry,account:number):Observable<object>
  {
    return this._http.put(`http://localhost:8090/api/v1/update/${account}`, entry);
  }
  getDataById(account:number):Observable<any>
  {
    return this._http.get<Entry[]>(`http://localhost:8090/api/v1/getTabById/${account}`);
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Entry } from '../entry';
import { EntryService } from '../entry.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit{

  entry = new Entry();
  msg='';
   constructor(private _service:EntryService,private _router:Router)
   {

   }
  ngOnInit(): void {
    
  }
  addData()
  {
     this._service.createtab(this.entry).subscribe(
       data=>{
         console.log("response recived");
         this.msg = "Data Submited"
         this._router.navigate(['/dash'])
         alert("Data Submited")
         window.location.reload();
       },
       error =>
       {
          console.log("Enter Proper Details");
       }
     )
  }

}

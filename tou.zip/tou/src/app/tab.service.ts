import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Tab } from './tab';

@Injectable({
  providedIn: 'root'
})
export class TabService {

  constructor(private http:HttpClient) { }
  findtab():Observable<Tab[]>
  {
    return this.http.get<Tab[]>(`http://localhost:8090/api/v1/gettab`); 
  }
}

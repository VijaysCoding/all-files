import { Component, OnInit} from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { TabService } from '../tab.service';
import { Tab } from '../tab';
import { EntryService } from '../entry.service';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';




@Component({
  selector: 'app-dash',
  templateUrl: './dash.component.html',
  styleUrls: ['./dash.component.css']
})
export class DashComponent implements OnInit {
  data:Tab[]=[];
  dataSource = new MatTableDataSource<Tab>(this.data);
  del:any;
  
  account = false;
  selectedAccount:any;
  
  constructor(private tabService:TabService,private entryService:EntryService, private router:Router)
  {
    this.tabService.findtab().subscribe(t=>{
      this.data=t;
      console.log(this.data);
    })  }
  displayedColumns = ['select','description','account', 'createdOn', 'createdBy','currency','del','upd'];

  ngOnInit(): void {
    
  }
  
  selection = new SelectionModel<Tab>(true, []);

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }
  
  deltab(account:number){
   this.entryService.deletetab(account).subscribe(data=>
    {
      console.log(data);
      
    })
  }
  reloadPage():void
  {
     window.location.reload();
  }
  onEdit(account:number){
     this.router.navigate(["updatetab",account])
  }
  showUpdatetab(accountId: any){
    this.account=true;
    this.selectedAccount = accountId;
  }
  
}

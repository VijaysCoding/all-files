export interface View {
    ename: string;
    cash: View[];
    account: number;
    createdOn: Date;
    createdBy: string;
    currency: string;
}
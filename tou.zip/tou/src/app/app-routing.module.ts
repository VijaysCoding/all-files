import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashComponent } from './dash/dash.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { TaskComponent } from './task/task.component';
import { UpdatetabComponent } from './updatetab/updatetab.component';
import { ViewComponent } from './view/view.component';

const routes: Routes = [
  {
    path:"",
    redirectTo:"dashboard",
    pathMatch:'full'
  },
  {
    path:"dashboard",
    component:DashboardComponent
  },
  {
    path:"home",
    component:HomeComponent
  },
  {
    path:"dash",
    component:DashComponent
  },
  {
    path:"task",
    component:TaskComponent
  },
  {
    path:"updatetab/:account",
    component:UpdatetabComponent
  },
  {
    path:"view",
    component:ViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

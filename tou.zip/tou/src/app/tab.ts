export interface Tab {
	description:string;
     account: number;
	 createdOn: Date;
	 createdBy: string;
	 currency: string;
}

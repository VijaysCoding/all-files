import { HttpClient } from '@angular/common/http'; 
import { Injectable } from '@angular/core'; 
import { Observable } from 'rxjs'; 
import { View } from './view';
 @Injectable({ 
   providedIn: 'root'
   }) 
   export class ViewService 
   { 
     private geturl = "http://localhost:8755/find"; 
     constructor(private http: HttpClient) { } 
     getTableValues(): Observable<View[]>
      { 
        return this.http.get<View[]>(`${this.geturl}`); 
      } 
    }
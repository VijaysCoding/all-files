export class Entry {
    description:string;
     account: number;
	 createdOn: Date;
	 createdBy: string;
	 currency: string;
}

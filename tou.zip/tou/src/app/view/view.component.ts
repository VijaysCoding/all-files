import { Component, OnInit, ViewChild } from '@angular/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import { Tree } from '../Service/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { TreeService } from '../Service/tree.service';
import { MatPaginator } from '@angular/material/paginator';


interface ExampleFlatNode 
{ expandable: boolean;
   name: string;  
   level: number;
}
const TREE_DATA: Tree[] = [];
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  ngOnInit(): void {
    
  }

  displayedColumns = ['name','uId', 'cgpa', 'jYear','pYear'];

  private transformer = (node: Tree, level: number) => 
  { 
    return { 
              expandable: !!node.childTree && node.childTree.length > 0,
              name: node.description,
              uId: node.uId,
              cgpa: node.cgpa,
              jYear: node.jYear,
              pYear: node.pYear,
              level: level,
            }; 
  } 
  treeControl = new FlatTreeControl<ExampleFlatNode>(node => node.level, node => node.expandable);
   treeFlattener = new MatTreeFlattener(
   this.transformer, 
   node => node.level, 
   node => node.expandable, 
   node => node.childTree);
   dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
   constructor(private treeService:TreeService) 
{
  this.dataSource.data = TREE_DATA;
  this.treeService.getTree().subscribe(TREE_DATA=>
    {
        this.dataSource.data=TREE_DATA;
        console.log(this.dataSource);
    })
}

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    // this.dataSource.= this.paginator;
  }
}

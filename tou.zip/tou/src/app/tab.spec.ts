import { Tab } from './tab';

describe('Tab', () => {
  it('should create an instance', () => {
    expect(new Tab()).toBeTruthy();
  });
});

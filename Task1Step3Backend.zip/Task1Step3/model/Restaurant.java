package com.ust.hierarchy.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;

@Entity
public class Restaurant {
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private int rid;
	
	private String name;
	
	@OneToMany(targetEntity = DishType.class, cascade = CascadeType.ALL)
	@JoinColumn(name="rid", referencedColumnName = "rid")
	private List<DishType> children;

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<DishType> getChildren() {
		return children;
	}

	public void setChildren(List<DishType> children) {
		this.children = children;
	}
	
	

}

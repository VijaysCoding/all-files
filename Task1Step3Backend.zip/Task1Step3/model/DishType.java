package com.ust.hierarchy.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;

@Entity
public class DishType {
	
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private int tid;
	
	private String name;
	
	@OneToMany(targetEntity = Dish.class, cascade = CascadeType.ALL)
	@JoinColumn(name="tid", referencedColumnName = "tid")
	private List<Dish> children;

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Dish> getChildren() {
		return children;
	}

	public void setChildren(List<Dish> children) {
		this.children = children;
	}
	
	

}

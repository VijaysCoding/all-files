package com.ust.hierarchy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ust.hierarchy.model.Restaurant;

@Service
public interface RestaurantService {
	
	//find all
	public List<Restaurant> getAll();
	
	//create
	public Restaurant create(Restaurant rest);
	
	//delete
	public void delete(int rid);
	
	// find by id
	public Restaurant findbyId(int rid);

}

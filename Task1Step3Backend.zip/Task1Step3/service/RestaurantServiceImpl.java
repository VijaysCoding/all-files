package com.ust.hierarchy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.hierarchy.model.Restaurant;
import com.ust.hierarchy.repo.RestaurantRepo;

@Service
public class RestaurantServiceImpl implements RestaurantService {
	
	
	@Autowired
	RestaurantRepo repo;

	@Override
	public List<Restaurant> getAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Restaurant create(Restaurant rest) {
		// TODO Auto-generated method stub
		return repo.save(rest);
	}

	@Override
	public void delete(int rid) {
		// TODO Auto-generated method stub
		repo.deleteById(rid);
	}

	@Override
	public Restaurant findbyId(int rid) {
		// TODO Auto-generated method stub
		return repo.findById(rid).get();
	}
	
	

}

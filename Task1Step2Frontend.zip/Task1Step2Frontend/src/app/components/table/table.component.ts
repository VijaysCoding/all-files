import { FlatTreeControl } from '@angular/cdk/tree';
import { Component } from '@angular/core';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { User } from 'src/app/user.model';
import { UserServiceService } from 'src/app/service/user-service.service';

interface ExampleFlatNode {
  expandable: boolean;
  name: string;
  level: number;
}

const TREE_DATA: User[] = [];

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent {


  displayedColumns: string[] = ['name', 'cId', 'dob', 'phno', 'salary'];
  private transFormer = (node: User, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      cId: node.cId,
      dob: node.dob,
      phno: node.phno,
      salary: node.salary,
      level: level
    };
  }

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    node => node.level, (node: { expandable: any; }) => node.expandable);

  treeFlattener = new MatTreeFlattener(
    this.transFormer, node => node.level,
    node => node.expandable, node => node.children);

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  constructor(private vService: UserServiceService) {
    this.dataSource.data = TREE_DATA;
    this.vService.getData().subscribe(TREE_DATA => {
      this.dataSource.data = TREE_DATA;
      console.log(this.dataSource);
    })
  }
  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

}

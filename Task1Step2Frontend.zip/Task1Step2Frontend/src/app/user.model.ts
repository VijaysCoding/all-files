export interface User {
    name: string;
    cId?: number,
    dob?: Date;
    phno?: number;
    salary?: number;
    children?: User[];
}

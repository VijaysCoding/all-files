import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient} from '@angular/common/http';
import { User } from '../user.model';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  getallUrl = 'http://localhost:8089/api/v/getall';

  constructor(private http: HttpClient) { }

  getData(): Observable<User[]>{
    return this.http.get<User[]>(this.getallUrl);
  }
}
